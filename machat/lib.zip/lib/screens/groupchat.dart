import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:machat/screens/shareImageContactList.dart'; // Import your ContactListScreen
import 'package:permission_handler/permission_handler.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';

class GroupChatScreen extends StatefulWidget {
  final String groupId;

  const GroupChatScreen({required this.groupId});

  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final TextEditingController _controller = TextEditingController();

  late String currentUserId;
  File? _imageFile;

  // To hold reply-related data
  String? _repliedMessageText;
  String? _repliedMessageSender;
  String? _repliedMessageImageUrl;
  String? _repliedMessageId;

  // List of messages to maintain state after deletion
  List<QueryDocumentSnapshot> _messages = [];

  @override
  void initState() {
    super.initState();
    currentUserId = _auth.currentUser!.uid;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<String?> _getProfilePictureUrl(String userId) async {
    try {
      final docSnapshot =
          await _firestore.collection('profilephoto').doc(userId).get();
      if (docSnapshot.exists) {
        return docSnapshot['profilePictureUrl'];
      }
    } catch (e) {
      print('Error fetching profile picture: $e');
    }
    return null;
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  Future<String?> _uploadImage(File image) async {
    try {
      final storageRef = _storage
          .ref()
          .child('chat_images/${DateTime.now().millisecondsSinceEpoch}');
      final uploadTask = storageRef.putFile(image);
      final snapshot = await uploadTask.whenComplete(() {});
      final imageUrl = await snapshot.ref.getDownloadURL();
      return imageUrl;
    } catch (e) {
      print('Error uploading image: $e');
      return null;
    }
  }

  void _sendMessage() async {
    if (_controller.text.trim().isEmpty && _imageFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cannot send an empty message')),
      );
      return;
    }

    final Map<String, dynamic> messageData = {
      'senderId': currentUserId,
      'timestamp': FieldValue.serverTimestamp(),
    };

    if (_controller.text.isNotEmpty) {
      messageData['text'] = _controller.text.trim();
    }

    if (_imageFile != null) {
      String? imageUrl = await _uploadImage(_imageFile!);
      if (imageUrl != null) {
        messageData['imageUrl'] = imageUrl;
      }
    }

    // Include reply message if present
    if (_repliedMessageText != null) {
      messageData['replyToMessage'] = {
        'sender': _repliedMessageSender,
        'text': _repliedMessageText,
        'imageUrl': _repliedMessageImageUrl,
      };
    }

    if (messageData.length > 2) {
      await _firestore
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .add(messageData);
    }

    setState(() {
      _controller.clear();
      _imageFile = null;
      _repliedMessageText = null; // Clear the reply after sending
      _repliedMessageSender = null;
      _repliedMessageImageUrl = null;
      _repliedMessageId = null;
    });
  }

  Future<bool> requestStoragePermission() async {
    if (await Permission.storage.isGranted) {
      return true;
    }

    final status = await Permission.storage.request();
    if (status.isGranted) {
      return true;
    } else if (status.isPermanentlyDenied) {
      await openAppSettings();
    }
    return false;
  }

  Future<void> downloadImage(String imageUrl) async {
    final hasPermission = await requestStoragePermission();

    if (!hasPermission) {
      print("Permission denied!");
      return;
    }

    try {
      final directory = await getExternalStorageDirectory();
      final filePath =
          "${directory!.path}/downloaded_image_${DateTime.now().millisecondsSinceEpoch}.jpg";

      final dio = Dio();
      await dio.download(imageUrl, filePath);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Image saved to Downloads folder')),
      );
      print("Image downloaded to $filePath");
    } catch (e) {
      print("Error downloading image: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to download image.')),
      );
    }
  }

  // Set the message to be replied to
  void _replyToMessage(BuildContext context, String? textMessage,
      String? imageUrl, String messageId) {
    setState(() {
      _repliedMessageText = textMessage ?? 'Replying to an image';
      _repliedMessageSender =
          currentUserId; // Track the sender of the replied message
      _repliedMessageImageUrl = imageUrl;
      _repliedMessageId = messageId; // Track the messageId for the reply
    });
    _controller.text = ''; // Clear the input field to focus on the reply.
  }

  void _redirectToContactListScreen(String? textMessage, String? imageUrl) {
    // Ensure null values are handled properly before passing them to ContactListScreen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ContactListScreen(
          textMessage:
              textMessage ?? '', // If textMessage is null, pass an empty string
          imageUrl: imageUrl, // imageUrl can stay null if it's a text message
          currentUserId: currentUserId, // Pass the current user ID here
        ),
      ),
    );
  }

  // Function to delete a message
  void _deleteMessage(String messageId) async {
    try {
      // Check if message exists
      var messageDoc = await _firestore
          .collection('groups')
          .doc(widget.groupId)
          .collection('messages')
          .doc(messageId)
          .get();

      if (messageDoc.exists) {
        // Message exists, proceed to delete
        await messageDoc.reference.delete();
        print("Message deleted successfully.");

        // Update local list of messages after deletion
        setState(() {
          _messages.removeWhere((message) => message.id == messageId);
        });
      } else {
        print("Message with ID $messageId does not exist.");
      }
    } catch (e) {
      print("Error deleting message: ${e.toString()}");
    }
  }

  void _showOptionsMenu(BuildContext context, String? textMessage,
      String? imageUrl, String messageId) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.forward),
              title: Text('Forward'),
              onTap: () {
                if (mounted) {
                  Navigator.pop(context); // Close the options menu
                  _redirectToContactListScreen(textMessage, imageUrl);
                  // Implement forward logic here
                }
              },
            ),
            if (textMessage != null || imageUrl != null)
              ListTile(
                leading: Icon(Icons.reply),
                title: Text('Reply'),
                onTap: () {
                  if (mounted) {
                    Navigator.pop(context); // Close the options menu
                    _replyToMessage(context, textMessage, imageUrl, messageId);
                  }
                },
              ),
            ListTile(
              leading: Icon(Icons.delete),
              title: Text('Delete'),
              onTap: () {
                _deleteMessage(messageId);
                Navigator.pop(context); // Close the bottom sheet
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Group Chat')),
      body: Column(
        children: [
          // Display reply preview if there's a message being replied to
          if (_repliedMessageText != null || _repliedMessageImageUrl != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                color: Colors.grey[200],
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    // If it's an image reply, show a small thumbnail
                    if (_repliedMessageImageUrl != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.network(
                          _repliedMessageImageUrl!,
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        ),
                      ),
                    // If it's a text reply, show the first part of the text
                    if (_repliedMessageText != null)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: Text(
                            _repliedMessageText!.length > 30
                                ? _repliedMessageText!.substring(0, 30) + '...'
                                : _repliedMessageText!,
                            style: TextStyle(
                              fontSize: 14,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),

          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('groups')
                  .doc(widget.groupId)
                  .collection('messages')
                  .orderBy('timestamp')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('No messages.'));
                }

                final messages = snapshot.data!.docs;

                return ListView.builder(
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final messageData =
                        messages[index].data() as Map<String, dynamic>;
                    final String message = messageData['text'] ?? '';
                    final String? imageUrl = messageData['imageUrl'];
                    final String senderId =
                        messageData['senderId'] ?? 'Unknown Sender';
                    final String messageId =
                        messages[index].id; // Get message ID

                    return FutureBuilder<String?>(
                      future: _getProfilePictureUrl(senderId),
                      builder: (context, photoSnapshot) {
                        String? profilePictureUrl = photoSnapshot.data;

                        return ListTile(
                          leading: CircleAvatar(
                            backgroundImage: profilePictureUrl != null
                                ? NetworkImage(profilePictureUrl)
                                : null,
                            child: profilePictureUrl == null
                                ? Icon(Icons.person)
                                : null,
                          ),
                          title: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // If there's a reply to a message, show it as a preview
                              if (messageData['replyToMessage'] != null)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 8.0),
                                  child: Container(
                                    color: Colors.grey[200],
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Replying to:',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                        if (messageData['replyToMessage']
                                                ['text'] !=
                                            null)
                                          Text(messageData['replyToMessage']
                                              ['text']),
                                        if (messageData['replyToMessage']
                                                ['imageUrl'] !=
                                            null)
                                          Image.network(
                                              messageData['replyToMessage']
                                                  ['imageUrl'],
                                              width: 50,
                                              height: 50),
                                      ],
                                    ),
                                  ),
                                ),
                              // Actual message text
                              if (imageUrl != null)
                                GestureDetector(
                                  onLongPress: () {
                                    _showOptionsMenu(
                                        context, null, imageUrl, messageId);
                                  },
                                  child: Image.network(
                                    imageUrl,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            Text('Image load failed'),
                                    loadingBuilder: (context, child, progress) {
                                      if (progress == null) return child;
                                      return Center(
                                        child: CircularProgressIndicator(
                                          value: progress
                                                  .cumulativeBytesLoaded /
                                              (progress.expectedTotalBytes ??
                                                  1),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                              if (message.isNotEmpty)
                                GestureDetector(
                                  onLongPress: () {
                                    _showOptionsMenu(
                                        context, message, null, messageId);
                                  },
                                  child: Text(
                                    message,
                                    style: TextStyle(fontSize: 16),
                                  ),
                                ),
                            ],
                          ),
                          subtitle: Text('Sender: $senderId'),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),

          if (_imageFile != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.file(_imageFile!),
            ),

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.photo),
                  onPressed: _pickImage,
                ),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(hintText: 'Enter a message'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
